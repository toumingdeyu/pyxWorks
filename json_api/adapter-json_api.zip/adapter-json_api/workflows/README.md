# Adapter Workflows

This directory contains workflows that support the adapter use cases. These workflows can be imported into IAP. If the adapter is installed using App-Artifact the workflows should be automatically imported.